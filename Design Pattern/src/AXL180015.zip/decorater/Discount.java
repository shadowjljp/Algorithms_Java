package decorater;

public interface Discount {
	void printName();
	void discount();
}
